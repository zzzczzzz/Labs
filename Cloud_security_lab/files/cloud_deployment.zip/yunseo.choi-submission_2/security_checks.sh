#!/bin/sh
# Security check script
# Copyright (C) Steve Kerrison <steve.kerrison@jcu.edu.au>
#
# Intended for use in CI to look for good/bad things in the application deployment
#
# Things you can do:
#  - Add more tests to prove that security measures you add work properly
#  - Use this to get _some_ idea of how well you're doing
# Things you cannot do:
#  - Assume the teacher uses the exact same test script
#  - Assume all tests are disclosed here
#
# Run in CI on a K8S-agent enabled runner in a bitnami image

# Errors that are tested for will be counted here. If non-zero at the end, script will also fail
ERRORS=0
TESTS=0
SKIP=0

fail () {
    echo -n "❌ "
    ERRORS=$((ERRORS+1))
    TESTS=$((TESTS+1))
}

win () {
    echo -n "✔ "
    TESTS=$((TESTS+1))
}

skip () {
    echo -n "❓ "
    SKIP=$((SKIP+1))
    TESTS=$((TESTS+1))
}

# Get all the information about the wordpress service in a single kubectl call
# Then we'll use `jq` to process this output several times to get individual fields
kubectl get svc wordpress -o json > wpsvc

# Get the ClusterIP of the wordpress service. This should always exist
CLUSTER_IP=$(jq -r '.spec.clusterIP' wpsvc)
CLUSTER_PORT=$(jq '.spec.ports[0].port' wpsvc)

cat <<EOT
Running tests
=============
EOT

# This doesn't work any more because there's no guarantee our runner is cluster-local.
# # Test if wordpress service can be reached
# echo "  Testing internal connection to http://${CLUSTER_IP}:${CLUSTER_PORT}"
# CODE=$(curl -s -o /dev/null --write-out "%{http_code}" http://${CLUSTER_IP}:${CLUSTER_PORT})

# if [ $? -ne 0 ]; then fail; else win; fi
# echo "Internal reachability"

# TODO: REMOVE as this code test is too simplistic
# Test if wordpress is installed/setup (check for the appropriate response codes)
CODE=$(curl -v -o /dev/null -L --stderr curlout --write-out "%{http_code}" http://${DOMAIN})
echo "Connectivity check: Response code was ${CODE}"
#if [ "${CODE}" != "200" ]; then fail; else win; fi
#echo "Wordpress deployed?"

echo "-------------"
echo "  Installation check"
if grep -q "/wp-admin/install.php" curlout; then fail;
elif grep -q "https://api.w.org/" curlout; then win; else fail; fi
echo "Wordpress is installed?"

# Check wordpress version by executing a tiny bit of PHP in the running container
# This is because the wordpress has a built-in update feature, so the container image version may not
# reliably indicate the installed version, or the labelled version may not match what's actually there
echo "-------------"
echo "  Version check"
if [ -z ${WPSCAN_TOKEN+x} ]; then
  skip
  echo "WPSCAN_TOKEN not set yet. You need to register at wpscan.com and then set it up in your project's Settings -> CI/CD -> Variables first!"
else
  echo "  Fetching wordpress version from pod"
  WP_VERSION=$(kubectl exec deploy/wordpress -- php -r 'include "wp-includes/version.php"; echo $wp_version;' | sed -e 's/\.//g' -e 's/0\+$//g')
  CI_WP_VERSION=$(echo ${WORDPRESS_VERSION} | cut -d- -f1 | sed -e 's/\.//g' -e 's/0\+$//g')
  if [ "$WP_VERSION" != "$CI_WP_VERSION" ]; then
    fail
    echo "Container is running $WP_VERSION but it's expected we deployed $CI_WP_VERSION"
  else
    echo "  Checking WP version ${WORDPRESS_VERSION} as '${WP_VERSION}' with wpscan"
    wget -O - --header "Authorization: Token token=${WPSCAN_TOKEN}" https://wpscan.com/api/v3/wordpresses/${WP_VERSION} | jq > wordpress-vulnerability-report.json
    NUM_VULN="$(cat wordpress-vulnerability-report.json | jq 'first(.[]).vulnerabilities | length')"
    if [ "0" == "$NUM_VULN" ]; then win; else fail; fi
    echo "$NUM_VULN Vulnerabilities found! Check wordpress-vulnerability-report.json artefact for more details."
  fi
fi

# Service external reachability
# TODO: This is no longer valid in th enew cluster setup, can it be replaced with a better security test?
# cat <<EOT
# Checking service reachability. Ideally MySQL should not be accessible externally at all,
# and Wordpress only via ingress, not via service. If these tests fail, then the services
# ARE reachable, but should not be.
# 
# To convert services between types (e.g. LoadBalancer to ClusterIP), you MAY need to delete
# the services \`kubectl delete svc {svcname}\` before re-deployment to clean up ceratin data.
# EOT
# 
# if [ ! -z $(kubectl get svc -o jsonpath='{.status.loadBalancer.ingress[0].ip}' wordpress) ]; then fail; else win; fi
# echo "Wordpress service direct external reachability"
# if [ ! -z $(kubectl get svc -o jsonpath='{.status.loadBalancer.ingress[0].ip}' wordpress-mysql) ]; then fail; else win; fi
# echo "MySQL service direct external reachability"

# Similar test to the installation test but doesn't follow redirects
# May give bad results if the installation test failed
# Ingress tests
echo "-------------"
echo "  HTTP check"
CODE=$(curl -v -o /dev/null --stderr curlout --write-out "%{http_code}" http://${DOMAIN})
if [ $? -ne 0 ]; then
    echo "  HTTP request failed for unexpected reason"
    fail
elif [ $CODE -eq 301 ] || [ $CODE -eq 308 ]; then 
    echo "HTTP redirects. Checking if it redirects to HTTPS"
    if grep -qi "< Location: https://" curlout; then
      win
    else
      echo "  Location was not HTTPS"
      fail
    fi
elif [ $CODE -ge 400 ] && [ $CODE -lt 500 ]; then
    echo "  HTTP 4xx error... good enough"
    win
elif [ $CODE -eq 200 ]; then
    echo "  HTTP 200: Serving on unencrypted HTTP!"
    fail
elif [ $CODE -eq 302 ]; then
    echo "  HTTP 302: Temporary redirect. Installation is probably incomplete."
    fail
else
    echo "Unhandled HTTP request result"
    fail
fi
echo "Port 80 (HTTP) errors or redirects to HTTPS?"

# SSL tests
# TODO:
# - Check TLS version
# - Check certificate validity
# - Check certificate type
echo "-------------"
echo "  TLS version check"
if openssl s_client -connect ${DOMAIN}:443 </dev/null 2>&1 | grep -q "   Protocol  : TLSv1.3"; then
  win
else
  fail
fi
echo "Is TLS version 1.3 supported?"

echo "-------------"
echo "  TLS certficate check"
set -o pipefail
if ! openssl s_client -connect ${DOMAIN}:443 </dev/null 2>/dev/null | openssl x509 -noout -text | grep -qe "DNS:.*traefik\.default"; then
  win
else
  fail
fi
echo "Is default Traefik certificate NOT used?"
set +o pipefail

echo "-------------"
echo "  TLS prefer ECC"
if openssl s_client -connect ${DOMAIN}:443 </dev/null 2>/dev/null | openssl x509 -noout -text | grep -q "Public Key Algorithm: id-ecPublicKey"; then
  win
else
  fail
fi
echo "Is ECC key is used rather than RSA?"

# Check if there's a WAF
echo "-------------"
echo "  Web Application Firewall checks"
echo "  1. SQLi"
CODE=$(curl -ko /dev/null --stderr curlout --write-out "%{http_code}" https://${DOMAIN}/?q=-1+union+select+1,2,3,4,5,6,7+--+)
if [ $? -ne 0 ]; then
    echo "  HTTP request failed for unexpected reason"
    fail
elif [ $CODE -eq 403 ] || [ $CODE -eq 406 ]; then 
    echo "  WAF appears to be blocking SQL injection"
    win
else
    echo "  No HTTP error on request with SQL injection"
    fail
fi
echo "WAF: SQL injection defence?"

# Check if there's a WAF
echo "  2. Path traversal"
CODE=$(curl -ko /dev/null --stderr curlout --write-out "%{http_code}" https://${DOMAIN}/?path=../../../etc/passwd)
if [ $? -ne 0 ]; then
    echo "  HTTP request failed for unexpected reason"
    fail
elif [ $CODE -eq 403 ] || [ $CODE -eq 406 ]; then 
    echo "  WAF appears to be blocking path traversal"
    win
else
    echo "  No HTTP error on request with path, got code ${CODE}"
    fail
fi
echo "WAF: Path traversal defence?"

# Get the CA certificate
kubectl get secret cp2422-root-secret -o jsonpath='{.data.ca\.crt}' | base64 -d > ca.crt
echo "testssl.sh will be run as a separate job in its own container, due to dependencies. The CA cert will be passed to it"

# See how well we did and decide how to exit
echo "-------------"
echo "${ERRORS} errors out of ${TESTS} tests detected, ${SKIP} skipped."
if [ $ERRORS -gt 0 ]; then
    exit 1
fi
