# CP2422 Blog Webapp

The [instructions for this project](https://gitlab.com/it-at-jcu/jcus-projects/cp2422-cloud-and-datacenter-security/assignment-3/-/wikis/Blog-Webapp) are now part of the [main assignment wiki](https://gitlab.com/it-at-jcu/jcus-projects/cp2422-cloud-and-datacenter-security/assignment-3/-/wikis/home)

## File list

A brief description of files in this project are below, which if you're looking to make comments, or even edits, may be useful:

- **Non-editable** _(unless you're very brave and knowledgable)_
  - **Scripts**
    - `security_checks.sh`: A script prepared by the project creator to do some integration tests. If you fix certain issues, the results of this script may change, but you cannot edit the script itself. It is run in a CI job called `dynamic_test`.
  - **Build files**
    - `Dockerfile`: We build a static version of Wordpress per the discussion in [Wordpress's Docker documentation](https://github.com/docker-library/docs/tree/master/wordpress#static-image--updates-via-redeploy), and this is the file that describes that.
  - **Informational**
    - `README.md`: This file. You're reading it _right now_.
    - `LICENSE`: A reminder that everything in here is proprietary and not to be shared without express permission
- **Editable** _(potentially, to a small degree... read the file comments)_
  - **CI files**
    - `.gitlab-ci.yml`: The CI file that defines jobs to deploy the application to Kubernetes, scan for security issues and run various tests. You can only really change the `variables:` section near the top of the file. It also builds the Wordpress container and pushes it to your docker registry.
  - **Kubernetes manifests**
    - `kutomization.yaml`: This file is used to list all the other files that will be combined and deployed. `kustomize` is a feature built into the `kubectl` command-line tool for Kubernetes.
    - **Bases**: These are files that don't _usually_ need changing, but can be patched with modified/additional content with `kustomize`
      - `certificate.yaml`: Defines a TLS/SSL certificate for your blog, but it isn't used by default.
      - `pki.yaml`: Defines the certificate authority that will be used to issue your blog's certificate. We can't/shouldn't use a public one, so we provide our own in this assignment.
      - `wordpress.yaml`: Defines a pod that will run your blog. It contains PHP (web-scripting language) + Apache (web server) + Wordpress (code).
      - `traefik-tls.yaml`: Instructs the cluster on some ingress TLS settings related to getting web traffic to your deployment.
    - **Patches**: Modifications to the base manifests, for example to set image names, versions, configs. In a big company you might have multiple sets of patches, one for each environment you're deploying to.
      - `certificate-domain.patch.yaml`: Sets the domain name of your SSL/TLS certificate.
      - `wordpress-config.patch.yaml`: Sets up your deployment's image name and database credentials.
      - `wordpress-route.patch.yaml`: Sets up routing to use the domain name associated with your K8S namespace.
      - `wordpress-tls.patch.yaml`: Sets up the domain information for your site's TLS settings.
    - **Templates**: These are `*.patch.tpl` versions of the `*.patch.yaml` files. They are used as source templates when your repository is first created and the variable names substituted for your environment. This is done automatically for you in this assignment, however.
